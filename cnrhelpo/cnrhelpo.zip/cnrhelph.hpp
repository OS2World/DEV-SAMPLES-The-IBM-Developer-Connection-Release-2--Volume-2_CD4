#ifndef _CNRHELPH_
#define _CNRHELPH_
//****************************************************************************
// CnrHelpHandler Class - C++ Header File (cnrhelph.hpp)                     *
//                                                                           *
// COPYRIGHT: Copyright (C) International Business Machines Corp., 1994,1995 *
//                                                                           *
// DISCLAIMER OF WARRANTIES:                                                 *
//   The following [enclosed] code is sample code created by IBM             *
//   Corporation.  This sample code is not part of any standard IBM product  *
//   and is provided to you solely for the purpose of assisting you in the   *
//   development of your applications.  The code is provided "AS IS",        *
//   without warranty of any kind.  IBM shall not be liable for any damages  *
//   arising out of your use of the sample code, even if they have been      *
//   advised of the possibility of such damages.                             *
//****************************************************************************
//NOTE: WE RECOMMEND USING A FIXED-SPACE FONT TO LOOK AT THE SOURCE.
//

#include <icnrhdr.hpp>               // ICnrHandler, parent class, which
                                     // indirectly includes ICnrHelpEvent.


//**************************************************************************
// Class:   CnrHelpHandler
//
// Purpose: Provides help support for a container.
//
//***************************************************************************
class CnrHelpHandler : public ICnrHandler
{

public:
   CnrHelpHandler(unsigned long helpId=0);
   virtual ~CnrHelpHandler();     //destructor

protected:
   Boolean help(ICnrHelpEvent& event);

private:
   unsigned long iCnrHelpId;


};   //CnrHelpHandler

#endif
