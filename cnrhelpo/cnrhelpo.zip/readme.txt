=====================================================================
cnrhelpo.zip    this package demonstrates how to define
                context-sensitive help for container columns
                and/or the container itself using VisualAge
                for C++ for OS/2.  (NOTE: to see how to provide
                the same help using VisualAge for C++ for Windows,
                get the cnrhelpw.zip package).
=====================================================================


This sample package (cnrhelpo.zip) file contains the following files:
=====================================================================
   CNRHELP.VBB  file that contains the following parts:
                CnrHelpSample, CnrHelpHandler, and ICnrHandler
   CNRHELPH.CPP source code for the class CnrHelpHandler,
                which overrides the help() member function.
   CNRHELPH.HPP header file for the class CnrHelpHandler
   CNRHLPSM.MAK make file used to build CNRHLPSM.EXE
                (NOTE: CNRHELPH.CPP was linked into the EXE,
                but you can build/package it however way you want)
   CNRHLPSM.EXE application that demonstrates context-sensitive help
                for direct-edit container columns and for a container
                itself
   CUSTOMER.IPF source help file containing context-sensitive help
   CUSTOMER.HLP help file (built using IPFC)
   README.TXT   this file
   VBLOAD.DAT   file used to load all the .VBB files for this sample.
                To use, invoke the Visual Builder (run ICSVB) from
                the directory that contains the .VBB files for this
                sample.

   The following files were pulled from the CNRSAMP.ZIP package:
   (see Q432: How to do Direct Edit in a Visual Builder Container)
   =============================================================
   ICNREDHR.VBB file that contains the ICnrEditHandler part
   IVBCEDHR.HPP header file for the class IVBCnrEditHandler
   IVBCEDHR.VBB file that contains the IVBCnrEditHandler part
   IVBCNR.C     source file for the IVBContainerControl template
                class (NOTE: this file was updated to enable
                container columns to be direct-edited).
   IVBCNR.H     header file for the IVBContainerControl template
                class (NOTE: this file was updated to enable
                container columns to be direct-edited).


Class Descriptions:
==========================================================================
   CnrHelpSample           Part that demonstrates how to define context-
                           sensitive help for a container column that
                           supports direct-edit or for the container itself.
   CnrHelpHandler          Handler that's used by CnrHelpSample to
                           provide context-sensitive help for the container
                           itself.  This handler can be used by any
                           IVBContainerControl* part.  The resource
                           id of the help panel that is to be displayed
                           for the container should be passed as a parm
                           on the constructor of this handler (i.e., when
                           you add it to the container's handler list).
   IVBCnrEditHandler       Handler that's used to provide direct-edit
                           support for the columns of a details view
                           container.


Instructions for viewing the parts packaged in this sample:
==========================================================================
   1. Load the .vbb files that are shipped in this package
      (CNRHELP.VBB, ICNREHDR.VBB, and IVBCEHDR.VBB).  Also
      load \ibmcpp\dde4vb\VBSAMPLE.VBB.  Optionally, these
      files will automatically get loaded if you invoke the
      Visual Builder (run ICSVB) from the directory that
      contains the .VBB files shipped in this package.

   2. Open the CnrHelpSample part.  This part shows how to
      define help for container columns and for the container
      itself (it also provides context-sensitive help for the
      entry fields that are labeled 'Work phone' and 'Home
      phone') using VisualAge for C++ for OS/2. More detailed
      instructions for providing help follow.


Instructions for defining container help:
==========================================================================
   -- To define help for a container column and/or a container,
      you must select the IHelpWindow* part from the Other
      category on the Parts Palette and drop it onto the
      freeform surface.  Open the settings for the IHelpWindow*
      part and specify the appropriate Help libraries (NOTE:
      this example, specified CUSTOMER.HLP as the help library).

   -- To define help for a container column that the user can
      direct edit (there's another sample that explains how
      to provide direct edit support for the columns of a
      details view container), connect the ready event of the
      freeform surface to the helpId attribute of the container
      column.  Open the connection settings, select the
      'Set parameters' push button, and then specify the
      appropriate resource id for the helpId field/attribute.
      The CnrHelpSample part defines help for the Work phone
      and Home phone container columns.

   -- To define help for the container itself, attach the
      CnrHelpHandler, which is provided in this package,
      to the container (NOTE: this handler can be attached
      to any IVBContainerControl part). Pass as a parameter
      the resource id of the help panel that is to be
      displayed. In CnrHelpSample, CnrHelpHandler(9999) is
      added to the container's list of handlers (open the
      container's settings and then tab to the Handler page.
      Note that IVBCnrEditHandler is also in the handler
      list.  This handler provides direct-edit support for
      details view container columns).


Instructions for executing this sample application:
==========================================================================
   -- Run CNRHLPSM.EXE.
   -- The initial focus should be on the container.  Select
      F1 to get help on the container itself.  This help
      panel explains how to update and get help on the
      'Work phone' and 'Home phone' container columns.
   -- Direct edit the 'Work phone' or 'Home phone' columns
      and then select F1.
   -- You can also select F1 when the 'Work phone' and 'Home
      phone' fields have focus.  The same help panel is shown
      for the 'Work phone' entry field and the 'Work phone'
      container column.  Likewise, the same help panel is shown
      for the 'Home phone' entry field and the 'Home phone'
      container column.


